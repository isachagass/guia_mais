<?php
include '../../database.php';

header("Access-Control-Allow-Origin: *"); // Pode trocar * pelo domínio do app
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Se for requisição OPTIONS (preflight), encerra aqui:
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

session_start(); // inicia a sessão no início

// Verifica se já está logado
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    http_response_code(403);
    echo json_encode(array(
        "success" => false,
        "message" => "Usuário já está logado.",
        "user" => array(
            "email" => $_SESSION['email'],
            "token" => $_SESSION['token']
        )
    ));
    exit();
}

$dados = json_decode(file_get_contents("php://input"), true);
$email = $dados['email'] ?? null;
$senha = $dados['password'] ?? null;

if(!$email || !$senha) {
    http_response_code(400);
    echo json_encode(array("message" => "Email e senha são obrigatórios."));
    exit();
}

$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$senha'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $token = bin2hex(random_bytes(16)); 
    $updateTokenSql = "UPDATE users SET token ='$token' WHERE email = '$email'";
    mysqli_query($conn, $updateTokenSql);   

    $_SESSION['email'] = $email;
    $_SESSION['loggedin'] = true;
    $_SESSION['token'] = $token;

    $user = mysqli_fetch_assoc($result);
    http_response_code(200);
    echo json_encode(array(
        "success" => true,
        "message" => "Login realizado com sucesso.",
        "user" => $user,
        "token" => $token
    ));

} else {
    http_response_code(401);
    echo json_encode(array("message" => "Email ou senha incorretos."));
}
