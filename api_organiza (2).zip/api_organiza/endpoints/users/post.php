<?php

include '../../database.php';

header("Access-Control-Allow-Origin: *");

header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}


$dados = json_decode(file_get_contents("php://input"), true);

$name = $dados['name'];
$email = $dados['email'];
$password = $dados['password'];
$created_at = date('Y-m-d H:i:s');

if(!$name || !$email || !$password) {
    http_response_code(400);
    echo json_encode(array("message" => "Name, email, and password are required."));
    exit();
}



$sql = "INSERT INTO users (name, email, password, created_at, updated_at) VALUES ('$name', '$email', '$password', '$created_at', '$created_at')";
if (mysqli_query($conn, $sql)) {
    http_response_code(201);
    echo json_encode(array("message" => "User created successfully"));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Error creating user: " . mysqli_error($conn)));
}
