<?php

include '../../database.php';

header("Access-Control-Allow-Origin: *"); // permite qualquer origem
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization");

header("Content-Type: application/json; charset=UTF-8");

session_start();
// if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
//     http_response_code(401);
//     echo json_encode([
//         "success" => false,
//         "message" => "Unauthorized"
//     ], JSON_UNESCAPED_UNICODE);
//     exit(); 
// }

$sql = "SELECT * FROM users";
$result = mysqli_query($conn, $sql);

$users = [];
if ($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $users[] = $row;
    }
}

http_response_code(200);
echo json_encode([
    "success" => true,
    "count"   => count($users),
    "data"    => $users
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
