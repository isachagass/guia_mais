<?php 

include '../../database.php';
header("Content-Type: application/json");
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Unauthorized"));
    exit();
}   
$dados = json_decode(file_get_contents("php://input"), true);
$user_id = isset($dados['id']) ? intval($dados['id']) : 0;
$name = $dados['name'];
$email = $dados['email'];   
$password = $dados['password'];
$updated_at = date('Y-m-d H:i:s');

if($user_id <= 0 || !$name || !$email || !$password) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid input. ID, name, email, and password are required."));
    exit();
}
$sql = "UPDATE users SET name='$name', email='$email', password='$password', updated_at='$updated_at' WHERE id=$user_id";
if (mysqli_query($conn, $sql)) {
    http_response_code(200);
    echo json_encode(array("message" => "User updated successfully"));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Error updating user: " . mysqli_error($conn)));
}
