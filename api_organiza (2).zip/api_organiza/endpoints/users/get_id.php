<?php 

include '../../database.php';
header("Content-Type: application/json");
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Unauthorized"));
    exit();
}

$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if($user_id <= 0) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid user ID"));
    exit();
}
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    http_response_code(200);
    echo json_encode($user);
} else {
    http_response_code(404);
    echo json_encode(array("message" => "User not found"));
}
