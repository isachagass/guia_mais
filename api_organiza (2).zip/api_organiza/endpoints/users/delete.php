<?php 

include '../../database.php';
header("Content-Type: application/json");
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Unauthorized"));
    exit();
}
$dados = json_decode(file_get_contents("php://input"), true);
$user_id = isset($dados['id']) ? intval($dados['id']) : 0;
if($user_id <= 0) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid user ID"));
    exit();
}   
$sql = "DELETE FROM users WHERE id = $user_id";
if (mysqli_query($conn, $sql)) {
    http_response_code(200);
    echo json_encode(array("message" => "User deleted successfully"));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Error deleting user: " . mysqli_error($conn)));
}