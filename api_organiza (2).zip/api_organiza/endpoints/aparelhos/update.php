<?php 

include '../../database.php';
header("Content-Type: application/json");
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Unauthorized"));
    exit();
}   
$dados = json_decode(file_get_contents("php://input"), true);

// $user_id = $dados['user_id'];
$user_id = $_SESSION['user_id'];

$aparelho_id = $dados['id'];
$name = $dados['name'];
$janelas = $dados['janelas'];
$lampadas = $dados['lampadas'];

if($aparelho_id <= 0 || empty($name) || empty($janelas) || empty($lampadas)) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid input"));
    exit();
}
$updated_at = date('Y-m-d H:i:s');
$sql = "UPDATE aparelhos SET name='$name', janelas='$janelas', lampadas='$lampadas', updated_at='$updated_at' WHERE id=$aparelho_id AND user_id=$user_id";
if (mysqli_query($conn, $sql)) {
    http_response_code(200);
    echo json_encode(array("message" => "Aparelho updated successfully"));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Error updating aparelho: " . mysqli_error($conn)));
}

