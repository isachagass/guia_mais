<?php
include '../../database.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
if (!isset($headers['Authorization'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$sql = "SELECT * FROM users WHERE token='$token'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) === 0) {
    http_response_code(401);
    echo json_encode(["message" => "Token inválido"]);
    exit();
}
$user = mysqli_fetch_assoc($result);
$user_id = $user['id'];

// pega o id do body
$dados = json_decode(file_get_contents("php://input"), true);
$aparelho_id = $dados['id'] ?? null;

if (!$aparelho_id) {
    http_response_code(400);
    echo json_encode(["message" => "ID não enviado"]);
    exit();
}

$sql = "DELETE FROM comodos WHERE id = $aparelho_id AND user_id = $user_id";
if (mysqli_query($conn, $sql)) {
    http_response_code(200);
    echo json_encode(["success" => true, "message" => "Aparelho deletado com sucesso"]);
} else {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Erro: " . mysqli_error($conn)]);
}
