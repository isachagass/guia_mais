<?php

include '../../database.php';
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
if (!isset($headers['Authorization'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$sql = "SELECT * FROM users WHERE token='$token'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) === 0) {
    http_response_code(401);
    echo json_encode(["message" => "não achei user Unauthorized"]);
    exit();
}
$user = mysqli_fetch_assoc($result);
$user_id = $user['id'];


session_start();
$dados = json_decode(file_get_contents("php://input"), true);


$sql = "SELECT * FROM comodos WHERE user_id = $user_id";
$result = mysqli_query($conn, $sql);
$aparelhos = array();
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $aparelhos[] = $row;
    }
}   
http_response_code(200);
echo json_encode($aparelhos, JSON_UNESCAPED_UNICODE);