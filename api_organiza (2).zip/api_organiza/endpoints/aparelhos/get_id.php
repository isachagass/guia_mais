<?php

include '../../database.php';
header("Content-Type: application/json; charset=UTF-8");

$dados = json_decode(file_get_contents("php://input"), true);

session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(array("message" => "Unauthorized"));
    exit();
}   


$email = $_SESSION['email'];
$user_id_query = "SELECT id FROM users WHERE email = '$email'";
$user_id = mysqli_query($conn, $user_id_query);
if (mysqli_num_rows($user_id_result) === 0) {
    http_response_code(404);
    echo json_encode(array("message" => "User not found"));
    exit();
}


// $user_id = $dados['user_id'];
$sql = "SELECT * FROM aparelhos WHERE user_id = $user_id AND id = " . intval($dados['id']);
$result = mysqli_query($conn, $sql);
$aparelhos = array();
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
        $aparelhos[] = $row;
    }
}   
http_response_code(200);
echo json_encode($aparelhos, JSON_UNESCAPED_UNICODE);