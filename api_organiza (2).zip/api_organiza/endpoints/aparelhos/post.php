<?php
include '../../database.php';

header("Access-Control-Allow-Origin: http://localhost:8081");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$headers = getallheaders();
if (!isset($headers['Authorization'])) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$sql = "SELECT * FROM users WHERE token='$token'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) === 0) {
    http_response_code(401);
    echo json_encode(["message" => "Unauthorized"]);
    exit();
}
$user = mysqli_fetch_assoc($result);
$user_id = $user['id'];

$dados = json_decode(file_get_contents("php://input"), true);

$nome = $dados['nome']; 
$lampadas = $dados['luzes'];
$janelas = $dados['janelas'];

// $email = $_SESSION['email'];
// $user_id_query = "SELECT id FROM users WHERE email = '$email'";
// $user_result = mysqli_query($conn, $user_id_query);

// if (mysqli_num_rows($user_result) === 0) {
//     http_response_code(404);
//     echo json_encode(array("message" => "User not found"));
//     exit();
// }

// $user_row = mysqli_fetch_assoc($user_result);
// $user_id = $user_row['id'];

$created_at = date('Y-m-d H:i:s');
if(!$nome || !$lampadas || !$janelas) {
    http_response_code(400);
    echo json_encode(array("message" => "Name, lampadas, janelas são obrigatórias."));
    exit();
}

$sql = "INSERT INTO comodos (name, lampadas, janelas, user_id, created_at, updated_at) VALUES ('$nome', '$lampadas', '$janelas', $user_id, '$created_at', '$created_at')";
if (mysqli_query($conn, $sql)) {
    http_response_code(201);
    echo json_encode(array("message" => "Cômodo cadastrado com sucesso"));
} else {
    http_response_code(500);
    echo json_encode(array("message" => "Erro ao cadastrar cômodo: " . mysqli_error($conn)));
}
